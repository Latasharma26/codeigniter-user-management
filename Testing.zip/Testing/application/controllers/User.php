<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('User_model');
    }

    // Display all users
    public function index()
    {
        $data['users'] = $this->User_model->get_users();
        $this->load->view('user_list', $data);
    }

    // Insert user
    public function create()
    {
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email')
        );
        $this->User_model->insert_user($data);
        redirect('user');
    }

    // Edit user - Show edit form
    public function edit($id)
    {
        $data['user'] = $this->User_model->get_user_by_id($id);
        $this->load->view('edit_user', $data);
    }

    // Update user
    public function update($id)
    {
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email')
        );
        $this->User_model->update_user($id, $data);
        redirect('user');
    }

    // Delete user
    public function delete($id)
    {
        $this->User_model->delete_user($id);
        redirect('user');
    }
}
