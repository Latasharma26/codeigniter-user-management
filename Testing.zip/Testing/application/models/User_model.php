<?php
class User_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Get all users
    public function get_users()
    {
        return $this->db->get('users')->result_array();
    }

    // Insert user
    public function insert_user($data)
    {
        return $this->db->insert('users', $data);
    }

    // Get user by ID
    public function get_user_by_id($id)
    {
        return $this->db->get_where('users', array('id' => $id))->row_array();
    }

    // Update user
    public function update_user($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('users', $data);
    }

    // Delete user
    public function delete_user($id)
    {
        return $this->db->delete('users', array('id' => $id));
    }
}
