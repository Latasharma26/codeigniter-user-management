<!DOCTYPE html>
<html>

<head>
    <title>Edit User</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('application/views/css/style.css'); ?>">
</head>

<body>
    <h2>Edit User</h2>

    <form method="post" action="<?php echo site_url('user/update/' . $user['id']); ?>">
        <input type="text" name="name" value="<?php echo $user['name']; ?>" required>
        <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
        <button type="submit">Update</button>
    </form>

    <br>
    <a href="<?php echo site_url('user'); ?>">Back to User List</a>
</body>

</html>